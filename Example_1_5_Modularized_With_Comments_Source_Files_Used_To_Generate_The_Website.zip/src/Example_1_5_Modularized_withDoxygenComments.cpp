/*! @mainpage Example 1.5 Modularized and with doxygen comments
 * @date Friday, January 29, 2021
 * @authors Pablo Gomez, Ariel Lutenberg and Eric Pernia
 * @section genDesc General Description
 *
 * This is a preliminary implementation of the smart home system, where the 
 * code has been modularized using functions and documented using Doxygen.
 * The entry point to the program documentation can be found at 
 * this \ref Example_1_5_Modularized_withDoxygenComments.cpp "link"
 *
 * @section genRem General Remarks
 * [Write here relevant information about the program]
 *
 * @section changelog Changelog
 *
 * |   Date     | Description                                    |
 * |:----------:|:-----------------------------------------------|
 * | 29/01/2021 | First version of program                       |
 *
 *
 */
 
/* Example of comment that follows C/C++ format, but not the doxygen standard */

//=====[Libraries]=============================================================

#include "mbed.h"
#include "arm_book_lib.h"

//=====[Declaration and initialization of public global objects]===============

DigitalIn enterButton(BUTTON1); /**< Object associated to 
                                     Enter key (B1 User Button) */
DigitalIn gasDetector(D2);  /**< Object associated to gas detector (D2) */
DigitalIn overTempDetector(D3); /**< Object associated to over temperature 
                                     detector (D3) */
DigitalIn aButton(D4); /**< Object associated to A key (pin D4) */
DigitalIn bButton(D5); /**< Object associated to B key (pin D5) */
DigitalIn cButton(D6); /**< Object associated to C key (pin D6) */
DigitalIn dButton(D7); /**< Object associated to D key (pin D7) */

DigitalOut alarmLed(LED1); /**< Output associated to alarm 
                                led indicator (LD1)*/
DigitalOut incorrectCodeLed(LED3); /**< Output associated to incorrect
                                        code indicator (LD3)*/
DigitalOut systemBlockedLed(LED2); /**< Output associated to system blocked 
                                        indicator (LD2)*/

//=====[Declaration and initialization of public global variables]=============

bool alarmState = OFF; /**< Alarm state flag */
int numberOfIncorrectCodes = 0; /**< Accounts for the number of incorrect codes 
                                     entered */

//=====[Declarations (prototypes) of public functions]=========================

void inputsInit();
/**<
 This function configures gasDetector, overTempDetector and aButton to dButton 
 with internal pull-down resistors.  
 @param none
*/

void outputsInit();
/**<
This function initializes the outputs of the system:
-# alarmLed = OFF
-# incorrectCodeLed = OFF
-# systemBlockedLed = OFF 
*/

void alarmActivationUpdate();
/**<
This function assigns ON to alarmLED if gasDetector or overTempDetector are 
active, and assigns alarmLed with alarmState. 
*/

void alarmDeactivationUpdate();
/**<
This function assesses the entered code and controls the activation of 
alarmLED, incorrectCodeLed, and systemBlockedLed. 
*/

//=====[Main function, the program entry point after power on or reset]========

/**
* Calls functions to initialize the declared input and output objects, and to 
* implement the system behavior.
* @param none
* @return The returned value represents the success 
* of application. 
*/
int main()
{
    inputsInit();
    outputsInit();
    while (true) {
        alarmActivationUpdate();
        alarmDeactivationUpdate();
    }
    return 0;
}         


//=====[Implementations of public functions]===================================

void inputsInit()
{
    gasDetector.mode(PullDown);
    overTempDetector.mode(PullDown);
    aButton.mode(PullDown);
    bButton.mode(PullDown);
    cButton.mode(PullDown);
    dButton.mode(PullDown);
}

void outputsInit()
{
    alarmLed = OFF;
    incorrectCodeLed = OFF;
    systemBlockedLed = OFF;
}

void alarmActivationUpdate()
{
    if ( gasDetector || overTempDetector ) {
        alarmState = ON;
    }
    alarmLed = alarmState;
}

void alarmDeactivationUpdate()
{
    if ( numberOfIncorrectCodes < 5 ) {
        if ( aButton && bButton && cButton && dButton && !enterButton ) {
            incorrectCodeLed = OFF;
        }
        if ( enterButton && !incorrectCodeLed && alarmState ) {
            if ( aButton && bButton && !cButton && !dButton ) {
                alarmState = OFF	;
                numberOfIncorrectCodes = 0;
            } else {
                incorrectCodeLed = ON;
                numberOfIncorrectCodes = numberOfIncorrectCodes + 1;
            }
        }
    } else {
        systemBlockedLed = ON;
    }
}
